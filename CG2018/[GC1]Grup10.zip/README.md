﻿Created by: Ever Garcia (NIA 194628, ID U137574) Roger Caritj (NIA 183714 ID U124305) Carlos Bertomeu (NIA 183768,ID U124294)

Actions:

When you're in any state different from 3, 4 and 6 clicking on the screen will produce a nice bubble effect.

- Press 1 to see an animation where a square is divided into four equal smaller squares that oscillate around the center.
	Press 1 to restart.

- Press 2 for an animation showing any number of color-changing, randomly located shapes including circles and squares. A new configuration is displayed every second.
	- Press up (navigation keypad) to increment the number of figures
	- Press down (navigation keypad) to decrement the number of figures
	- Press F to switch to a mode in which figures are colored on the inside.
	- Press U to switch back to only-edges drawing mode.

- Press 3 for a snowing animation.
	- Click left to decrease the amount of snowflakes (there's still a minimum though from where it restarts).

- Press 4 to see a famous painting.
	- Click left anywhere to change some colors.

- Press 6 for image editing. An image should pop up on the screen, and a blur effect will be applied on it once.
	- Press 6 (again) to re-apply effect on top of current degradation.

- Press 7 for an animation showing some color-changing shapes including a "clock" spinning around its circumference with a non-straight line as time goes by.
	- Press F to switch to a mode in which the four circles on the edges of the square are colored on the inside.
	- Press U to switch back to only-edges drawing mode.

- Press 8 for interactive, shape-drawing mode. The size (radius or side length) of the shapes is random, just like their color.
	- Press left click for circles.
	- Press right click for squares.
	- Press F to switch to a mode in which figures are colored on the inside.
	- Press U to switch back to only-edges drawing mode.

You can switch between actions as you please and the changes are saved in some modes.

Enjoy!